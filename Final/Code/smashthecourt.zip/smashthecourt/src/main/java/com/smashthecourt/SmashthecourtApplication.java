package com.smashthecourt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmashthecourtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmashthecourtApplication.class, args);
	}

}
