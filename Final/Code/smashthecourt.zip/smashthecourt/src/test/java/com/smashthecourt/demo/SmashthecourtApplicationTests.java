package com.smashthecourt.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmashthecourtApplicationTests {

	@Test
	void contextLoads() {
	}

}
